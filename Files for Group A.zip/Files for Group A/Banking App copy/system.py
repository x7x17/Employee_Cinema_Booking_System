import pandas as pd
import sqlite3
from datetime import datetime 

con = sqlite3.connect('bank2.db', isolation_level=None)
c = con.cursor()

class Account:
    def __init__(self, username, password):
        self.username = username
        self.password = password
        
    def login(self):
        print("-------------------------")
        # Query verifying username and password in database
        query = c.execute("SELECT * FROM ACCOUNTS WHERE username = ? and password = ?;", (self.username, self.password))
        result = query.fetchone() # Returns list with each index correspinding to columnm in database row
        if result == None:
            print("Incorrect username / password.")
        else:
            # Assigns instance variables via query result 
            if self.username == result[1] and self.password == result[2]:
                self.name = result[3]
                self.an = result[4]
                self.sc = result[5]
                self.balance = result[6]
            print("Hello ", self.name)
            print("-------------------------")

    def show_balance(self):
        print("-------------------------")
        # Checks database for username and password
        query = c.execute("SELECT * FROM ACCOUNTS WHERE username = ? and password = ?;", (self.username, self.password))
        # Returns list of username and password in row
        result = query.fetchone()
        # 6th index of list is balance
        self.balance = result[6]
        print("Your current balance is: ", "£", self.balance)
        print("-------------------------")
        
    def transaction(self):
        print("-------------------------")
        # Assign transaction variables
        sender_an = self.an
        sender_sc = self.sc
        recipient_an = int(input("Recipient account number: "))
        recipient_sc = int(input("Recipient sortcode: "))
        amount = input("Amount: ")
        today = datetime.now().strftime('%Y-%m-%d')
        reference = input("Reference: ")
        
        # Query fetching rows with recipient account details
        credential_check = c.execute("""SELECT account_number, sort_code FROM accounts WHERE account_number = ? and sort_code = ?""",
                                     (recipient_an, recipient_sc))
        result = credential_check.fetchone() 
        # Check accounts exist and sender can afford transaction
        if self.balance >= float(amount) and result[0] == recipient_an and result[1] == recipient_sc:
            # Insert transaction row into transactions table
            c.execute("""INSERT INTO transactions (date, sender_account_number, sender_sortcode, recipient_account_number,
                        recipient_sortcode, amount, reference) VALUES(?, ?, ?, ?, ?, ?, ?);""",
                        (today, self.an, self.sc, recipient_an, recipient_sc, amount, reference))
            # Update recipient balance in accounts table
            c.execute("UPDATE accounts SET balance = balance + ? WHERE account_number = ? and sort_code = ?;",
                      (amount, recipient_an, recipient_sc))
            # Update sender balance in accounts table
            c.execute("UPDATE accounts SET balance = balance - ? WHERE account_number = ? and sort_code = ?;",
                      (amount, self.an, self.sc))

            print("Transaction complete.")
            print("-------------------------")
            print("Transaction Summary: ")
            print("Sent: £", amount)
            print("To: ", recipient_an, "|", recipient_sc)
            print("Reference: ", reference)
            print("-------------------------")
        else:
            print("Transaction cannnot be processed")
    
    def show_transactions(self):
        print("-------------------------")
        print("Recent Transactions:")
        print("-------------------------")
        # SQL query fetching transactions of signed in account        
        query = c.execute("SELECT * FROM transactions WHERE sender_account_number = ? OR recipient_account_number = ? ORDER BY tid DESC;", (self.an, self.an))
        # Returns list of lists where list of list = row in transactions table
        result = query.fetchall()
        for x in result:
            # If money has been recieved:
            if self.an == x[2]:
                print("Money in:", "£", x[6], "|", "Reference:", x[7])
            # If money has been sent:
            if self.an == x[4]:
                print("Money out:", "£", x[6], "|", "Reference:", x[7])
        print("-------------------------")

# Creates Account object with user input as username/password instance variables
cA = Account(input("username: "), input("password: "))

# Calls login function
cA.login()

# Loops over program so user can select another option
while True:
    print("Please select an option:")
    print("1 - Show balance. 2 - Make a transaction. 3 - View recent transactions.")
    print("-------------------------")
    useroption = int(input())
    if useroption == 1:
        cA.show_balance()
    if useroption == 2:
        cA.transaction()
    if useroption == 3:
        cA.show_transactions()

    
